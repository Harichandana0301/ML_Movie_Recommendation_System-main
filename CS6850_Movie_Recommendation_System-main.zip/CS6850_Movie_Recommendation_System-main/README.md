# This Movie Recommendation System project code has three repositories:  

## CS6850_Movie_Recommendation_System: https://github.com/Dheeraj0650/CS6850_Movie_Recommendation_System

## CS6850_Movie_Recommendation_System_Frontend: https://github.com/Dheeraj0650/CS6850_Movie_Recommendation_System_Frontend

## CS6850_Movie_Recommendation_System_Backend: https://github.com/Dheeraj0650/CS6850_Movie_Recommendation_System_Backend
